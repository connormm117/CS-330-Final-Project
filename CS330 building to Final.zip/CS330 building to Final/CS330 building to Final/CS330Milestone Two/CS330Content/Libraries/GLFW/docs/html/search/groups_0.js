var searchData=
[
  ['context_20reference_0',['Context reference',['../group__context.html',1,'']]]
];
